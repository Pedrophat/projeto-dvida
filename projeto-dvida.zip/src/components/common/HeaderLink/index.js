import { Anchor } from './styles'

export default function HeaderLink(props) {
  return(
    <Anchor>{props.TextoDoLink}</Anchor>
  )
}
