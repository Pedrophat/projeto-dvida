import styled from 'styled-components'
import Header from '../components/Header'


const Teste = styled.div`
background: #000;
`

export default function Home() {
  return (
    <div>
      <Header/>
      <Teste>
        aoba
      </Teste>
    </div>
  )
}
